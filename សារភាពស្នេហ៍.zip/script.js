const noBtn = document.querySelector('.No');
const yesBtn = document.querySelector('.Yes');
const h1 = document.querySelector('h1');
const h2 = document.querySelector('h2');
const img = document.querySelector('img');

noBtn.addEventListener('mouseover', () => {
    const yesRect = yesBtn.getBoundingClientRect();
    let randomX, randomY;
    
    do {
        randomX = Math.floor(Math.random() * (window.innerWidth - noBtn.offsetWidth));
        randomY = Math.floor(Math.random() * (window.innerHeight - noBtn.offsetHeight));
    } while (
        randomX < yesRect.right &&
        randomX + noBtn.offsetWidth > yesRect.left &&
        randomY < yesRect.bottom &&
        randomY + noBtn.offsetHeight > yesRect.top
    );

    noBtn.style.position = 'absolute';
    noBtn.style.left = randomX + 'px';
    noBtn.style.top = randomY + 'px';
});

yesBtn.addEventListener('click', () => {
    h1.textContent = "THANK YOU!";
    h2.textContent = "រៀបការនឹងបងបានអត់!💍👸😝❤️";
    img.src = "IMG_1652.gif"; 
    yesBtn.style.display = 'none';
    noBtn.style.display = 'none';
});
